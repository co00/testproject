<?php
include("model/model.php");
$obj = new model();


// Admin Login

if(isset($_POST['username'])){

	if (empty($_POST['username']) && empty($_POST['password'])) 
	{
		echo json_encode(['statuscode'=>false,'msg'=>'Username and Password is required']);
	}else{

		echo $obj->adminlogin($c,'admin',$_POST['username'],md5($_POST['password']));
	}
}


if(isset($_POST['classesame'])){
	
	if ($obj->check_exist($c,'classes',['name'=>$_POST['classesame']])) {
		echo json_encode(['statuscode'=>false,'msg'=>'Class name already exist.']);
	}else{

		$is_success = $obj->insert($c,'classes',['name'=>$_POST['classesame'],'teachers_id'=>$_POST['teachers_id'],'created_at'=>date('Y-m-d H:s:i')]);

		if ($is_success) {
			echo json_encode(['statuscode'=>true,'msg'=>'Recourd insert success.']);
		}else{
			echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
		}
	}

}

if (isset($_GET['edit_classes'])) {

	$data = $obj->get_one_row($c,'classes',['id'=>$_GET['edit_classes']]);

	echo json_encode(['statuscode'=>true,'msg'=>'Recourd Found','data'=>$data]); 
}

if (isset($_GET['delete_classes'])) 
{

	$is_success = $obj->delete($c,'classes',['id'=>$_GET['delete_classes']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}

if (isset($_POST['updateClass_name'])) 
{

	$is_success = $obj->update($c,'classes',"name='".$_POST['updateClass_name']."',teachers_id='".$_POST['updateTeachers_id']."'",['id'=>$_POST['updateClass_id']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}

// Teacher 

if(isset($_POST['teacherame'])){
	
	if ($obj->check_exist($c,'teachers',['name'=>$_POST['teacherame']])) {
		echo json_encode(['statuscode'=>false,'msg'=>'Teacher name already exist.']);
	}else{

		$is_success = $obj->insert($c,'teachers',['name'=>$_POST['teacherame'],'created_at'=>date('Y-m-d H:s:i')]);

		if ($is_success) {
			echo json_encode(['statuscode'=>true,'msg'=>'Recourd insert success.']);
		}else{
			echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
		}
	}

}

if (isset($_GET['edit_teachers'])) {

	$data = $obj->get_one_row($c,'teachers',['id'=>$_GET['edit_teachers']]);

	echo json_encode(['statuscode'=>true,'msg'=>'Recourd Found','data'=>$data]); 
}

if (isset($_GET['delete_teachers'])) 
{

	$is_success = $obj->delete($c,'teachers',['id'=>$_GET['delete_teachers']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}

if (isset($_POST['updateTeachers_name'])) 
{

	$is_success = $obj->update($c,'teachers',"name='".$_POST['updateTeachers_name']."'",['id'=>$_POST['updateTeachers_id']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}

// Student 


if(isset($_POST['studentname'])){
	
	if ($obj->check_exist($c,'student',['name'=>$_POST['studentname']])) {
		echo json_encode(['statuscode'=>false,'msg'=>'Student name already exist.']);
	}else{

		$is_success = $obj->insert($c,'student',['name'=>$_POST['studentname'],'classes_id'=>$_POST['classes_id'],'created_at'=>date('Y-m-d H:s:i')]);

		if ($is_success) {
			echo json_encode(['statuscode'=>true,'msg'=>'Recourd insert success.']);
		}else{
			echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
		}
	}

}

if (isset($_GET['edit_student'])) {

	$data = $obj->get_one_row($c,'student',['id'=>$_GET['edit_student']]);

	echo json_encode(['statuscode'=>true,'msg'=>'Recourd Found','data'=>$data]); 
}

if (isset($_GET['delete_student'])) 
{

	$is_success = $obj->delete($c,'student',['id'=>$_GET['delete_student']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}

if (isset($_POST['updateStudent_name'])) 
{

	$is_success = $obj->update($c,'student',"name='".$_POST['updateStudent_name']."',classes_id='".$_POST['updateClasses_id']."'",['id'=>$_POST['updateStudent_id']]);

	if ($is_success) {
		echo json_encode(['statuscode'=>true,'msg'=>'Recourd deleted success.']);
	}else{
		echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
	}
}


// Attendance..

if (isset($_GET['attendance_student_id'])) 
{



	if ($obj->check_exist($c,'attendance',['student_id'=>$_GET['attendance_student_id'],'attendance_date'=>date('Y-m-d')])) {
		echo json_encode(['statuscode'=>false,'msg'=>'Student todays attendance already exist.']);
	}else{

		$is_success = $obj->insert($c,'attendance',['student_id'=>$_GET['attendance_student_id'],'classes_id'=>$_GET['classes_id'],'enroll_unenroll'=>$_GET['enroll_unenroll'],'attendance_date'=>date('Y-m-d'),'created_at'=>date('Y-m-d H:s:i')]);

		if ($is_success) {
			echo json_encode(['statuscode'=>true,'msg'=>'Recourd insert success.']);
		}else{
			echo json_encode(['statuscode'=>false,'msg'=>'Something went wrong.']);
		}
	}
}

?>