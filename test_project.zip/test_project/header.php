<?php
include('controller/controller.php');

if (!isset($_SESSION['aid'])) {
	header('Location: index.php');
}
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>

<div class="content">
	<div class="container-fluid">
		<div> 