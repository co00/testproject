<?php

class connection
{
	public function conn()
	{
		session_start();

		$hostname = "localhost";
		$user = "root";
		$pass = "";
		$db = "test_db";

		$con = new mysqli($hostname,$user,$pass,$db);
		return $con;
	}
}

?>