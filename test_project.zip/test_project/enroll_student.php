<?php include('header.php'); ?> 
			
			

			<div class="col-md-12" style="margin-top: 50px;">
			
				<div class="panel panel-default">
				  <div class="panel-heading" style="background:#000;color:white;">
				    <h3 class="panel-title" style="font-weight: bold;">Attendance</h3>
				  </div>

				  	<div class="panel-body">
					  <a href="dashboard.php" class="btn btn-danger btnlogin">Back</a>


					  <div style="margin-top: 50px;">

					  	<?php if (!empty($enroll_student)) { ?>

					  		<table class="table table-hover">
					  		  <thead>
					  		    <tr style="background: #212529; color: #fff;">
					  		      <th scope="col">#</th>
					  		      <th scope="col">Student Name</th>
					  		    </tr>
					  		  </thead>
					  		  <tbody>

					  		  	<?php $no = 1; while ($data = $enroll_student->fetch_assoc()) { ?>

					  		    <tr>
					  		      <th scope="row"><?=$no?></th>
					  		      <td><?=$data['student_name']?></td>
					  		    </tr>

					  		<?php $no++; } ?>
					  		  </tbody>
					  		</table>
					  	<?php }else{ ?>

					  		<div class="alert alert-danger">No Recourd.</div>
					  	<?php } ?>
					  </div>

					</div>

				</div>
			
		</div>
			
		

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Add Classes</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="row">

        	<div class="col-md-12">
        		<div class="txtError"></div>
        	</div>

        	<div class="col-md-12">
        		<b>Class Name</b>
        		<input type="text" class="form-control" id="name" name="">
        	</div>

        	<div class="col-md-12">
        		<b>Teachers</b>
        		<select class="form-control" id="teachers_id">
        			<?php if (!empty($teachers)) { while ($data = $teachers->fetch_array()) {  ?>
        			<option value="<?=$data['id']?>"><?=$data['name']?></option>
        			<?php } } ?>
        		</select>
        	</div>

        	<input type="hidden" name="" id="id">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary  addClass">Submit</button>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

<script type="text/javascript">
	
	$(document).ready(function(){


	});

</script>