<?php include('header.php'); ?> 
			
			<div class="col-md-12" style="margin-top: 50px;">
			
				<div class="panel panel-default">
				  <div class="panel-heading" style="background:#000;color:white;">
				    <h3 class="panel-title" style="font-weight: bold;">Attendance</h3>
				  </div>

				  	<div class="panel-body">
					  <a href="dashboard.php" class="btn btn-danger btnlogin">Back</a>


					  <div style="margin-top: 50px;">

					  	<?php if (!empty($attendance_student)) { ?>

					  		<table class="table table-hover">
					  		  <thead>
					  		    <tr style="background: #212529; color: #fff;">
					  		      <th scope="col">#</th>
					  		      <th scope="col">Class Name</th>
					  		      <th scope="col">Action</th>
					  		    </tr>
					  		  </thead>
					  		  <tbody>

					  		  	<?php $no = 1; while ($data = $attendance_student->fetch_assoc()) { ?>

					  		    <tr>
					  		      <th scope="row"><?=$no?></th>
					  		      <td><?=$data['name']?></td>
					  		      <td>
					  		      	<a href="data.php?attendance_student_id=<?=$data['id']?>&classes_id=<?=$data['classes_id']?>&enroll_unenroll=enroll" class="enroll btn btn-primary">Enroll</a>
					  		      	<a href="data.php?attendance_student_id=<?=$data['id']?>&classes_id=<?=$data['classes_id']?>&enroll_unenroll=unenroll" class="unenroll btn btn-danger" class="text-danger" style="margin-left: 10px;">Un-Enroll</a>
					  		      </td>
					  		    </tr>

					  		<?php $no++; } ?>
					  		  </tbody>
					  		</table>
					  	<?php }else{ ?>

					  		<div class="alert alert-danger">No Recourd.</div>
					  	<?php } ?>
					  </div>

					</div>

				</div>
			
		</div>
			
		

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Add Classes</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="row">

        	<div class="col-md-12">
        		<div class="txtError"></div>
        	</div>

        	<div class="col-md-12">
        		<b>Class Name</b>
        		<input type="text" class="form-control" id="name" name="">
        	</div>

        	<div class="col-md-12">
        		<b>Teachers</b>
        		<select class="form-control" id="teachers_id">
        			<?php if (!empty($teachers)) { while ($data = $teachers->fetch_array()) {  ?>
        			<option value="<?=$data['id']?>"><?=$data['name']?></option>
        			<?php } } ?>
        		</select>
        	</div>

        	<input type="hidden" name="" id="id">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary  addClass">Submit</button>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

<script type="text/javascript">
	
	$(document).ready(function(){


		$(document).off('click','.addClass').on('click','.addClass',function(e){


			if ($('#name').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Class Name is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						classesame:$('#name').val(),
						teachers_id:$('#teachers_id').val()
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location="classes.php";
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

		 $(document).off('click','.enroll').on('click','.enroll',function(e){
            e.preventDefault();
            var self = $(this);

            $.ajax({

					url:self.attr('href'),
					dataType:'JSON',
					success:function(response){
						if (response.statuscode) 
						{	
							self.closest('tr').remove();

						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});

           });

		 $(document).off('click','.unenroll').on('click','.unenroll',function(e){
            e.preventDefault();
            var self = $(this);

            $.ajax({

					url:self.attr('href'),
					dataType:'JSON',
					success:function(response){
						if (response.statuscode) 
						{	
							self.closest('tr').remove();

						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});

           });

		 $(document).off('click','.delete').on('click','.delete',function(e){
            e.preventDefault();
            var self = $(this);

            if( confirm('Are you sure, you want to delete this record?') ) {
                $(".loader").removeClass('hidden');
                var url = self.attr('href');
                $.ajax({
                    url: url,
                    dataType: 'JSON',
                    success: function(response) {
                        if( response.statuscode ) {
                            self.closest('tr').remove();
                            alert(response.msg);
                        }
                    }
                });
            }
        });

		 $(document).off('click','.updateClass').on('click','.updateClass',function(e){

			if ($('#name').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Class Name is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						updateClass_name:$('#name').val(),
						updateTeachers_id:$('#teachers_id').val(),
						updateClass_id:$('#id').val(),
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location="classes.php";
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

	});

</script>