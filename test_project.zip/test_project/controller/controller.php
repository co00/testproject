<?php
include("model/model.php");
$obj = new model();


$classes = $obj->get_all($c,'classes');
$teachers = $obj->get_all($c,'teachers');

$classes_with_teachers = $obj->get_with_join($c,'classes','classes.id as id,classes.name as name,teachers.name as teachers_name','LEFT JOIN teachers ON teachers.id = classes.teachers_id');

$student_with_teachers = $obj->get_with_join($c,'student','student.id as id,student.name as name,classes.name as classes_name,teachers.name as teachers_name','LEFT JOIN classes ON classes.id = student.classes_id LEFT JOIN teachers ON teachers.id = classes.teachers_id');


// Attendance Student list using Class id 

if (isset($_GET['classes_id'])) 
{	 
	$attendance_student =  $obj->get_with_where_not($c,'student',['classes_id'=>$_GET['classes_id']],$_GET['classes_id']);

}

if (isset($_GET['enroll_student_classes_id'])) 
{	 
	$enroll_student = $obj->get_with_join($c,'attendance','attendance.id as id,student.name as student_name','LEFT JOIN student ON student.id = attendance.student_id where attendance.classes_id="'.$_GET['enroll_student_classes_id'].'" and attendance.enroll_unenroll="enroll"');

	//echo '<pre>'; print_r($enroll_student->num_rows); die();

	// echo '<pre>'; print_r($enroll_student); die();
}



if (isset($_GET['unenroll_student_classes_id'])) 
{	 
	$enroll_student = $obj->get_with_join($c,'attendance','attendance.id as id,student.name as student_name','LEFT JOIN student ON student.id = attendance.student_id where attendance.classes_id="'.$_GET['unenroll_student_classes_id'].'" and attendance.enroll_unenroll="unenroll"');

	//echo '<pre>'; print_r($enroll_student->num_rows); die();

	// echo '<pre>'; print_r($enroll_student); die();
}



?>