<?php include('header.php'); ?>  
			
			

			<div class="col-md-12" style="margin-top: 50px;">
			
				<div class="panel panel-default">
				  <div class="panel-heading" style="background:#000;color:white;">
				    <h3 class="panel-title" style="font-weight: bold;">Dashboard</h3>
				  </div>

				  	<div class="panel-body">


					  <a href="teachers.php" class="btn btn-success">Teachers</a>
					  <a href="classes.php" class="btn btn-danger">Classes</a>
					  <a href="student.php" class="btn btn-primary">Student</a>


					  <?php if (!empty($classes)) { ?>

					  <div class="col-md-12" style="margin-top: 30px;">

					  	<h2>Today List</h2><hr>

					  	<?php $no = 1; while ($data = $classes->fetch_array()) { ?>
					  	
					  	<div class="col-md-4" style="box-shadow: 2px 2px 5px 2px #888888; padding: 10px; margin: 5px;">
					  		<h5><?=$data['name']?></h5><hr>
					  		<a href="attendance.php?classes_id=<?=$data['id']?>" class="btn btn-primary">Attendance</a>
					  		<a href="enroll_student.php?enroll_student_classes_id=<?=$data['id']?>" class="btn btn-success">Enroll Student</a>
					  		<a href="unenroll_student.php?unenroll_student_classes_id=<?=$data['id']?>" class="btn btn-danger">Un-enroll Student</a>
					  	</div>	

					  <?php } ?>

					  </div>

					<?php } ?>

					</div>

				</div>
			
		</div>
			
		

<?php include('footer.php') ?>

<script type="text/javascript">
	
	$(document).ready(function(){

		$(document).off('click','.btnlogin').on('click','.btnlogin',function(e){


			if ($('#username').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Username is Required</div>');
			}else if ($('#password').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Password is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						username:$('#username').val(),
						password:$('#password').val()
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location='dashboard.php';
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

	});

</script>