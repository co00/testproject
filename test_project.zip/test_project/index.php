<?php
include('controller/controller.php');

if (isset($_SESSION['aid'])) {
	header('Location: dashboard.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>


<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>

<div class="container">	
<div class="col-md-2"></div>	
	<div class="col-md-6" style="margin-top: 50px;">                    
		<div class="panel panel-info">
			<div class="panel-heading" style="background:#000;color:white;">
				<div class="panel-title">Admin Login</div>                        
			</div> 
			<div style="padding-top:30px" class="panel-body" >

				<div class="txtError"></div>
				                                    
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<input type="text" class="form-control" id="username" name="username" placeholder="username" required>                                        
					</div>                                
					<div style="margin-bottom: 25px" class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input type="password" class="form-control" id="password" name="password" placeholder="password" required>
					</div>
					<div style="margin-top:10px" class="form-group">                               
						<div class="col-sm-12 controls">
						  <button class="btn btn-success btnlogin">Login</button>						  
						</div>						
					</div>	
					<div style="margin-top:10px" class="form-group">                               
						<div class="col-sm-12 controls">
							<br>
						Username: admin<br>
						password:admin	<br><br>									
						</div>						
					</div>	   
			</div>                     
		</div>  
	</div>
</div>
<!-- 
	<div class="row">
		
		<div class="col-md-4" style="margin-left: 30%; margin-top:10%;">
			
				<div class="panel panel-default">
				  <div class="panel-heading" style="background: #62488A;">
				    <h3 class="panel-title" style="color: #fff; font-weight: bold;">Admin Login</h3>
				  </div>

				  	<div class="panel-body">

				  	<div class="txtError"></div>

					  <div class="form-group">
					  		<b>Username</b>
					  		<input type="text" class="form-control" id="username" name="username" placeholder="Enter Username">
					  </div>

					  <div class="form-group">
					  		<b>Password</b>
					  		<input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
					  </div>

					  <div class="form-group">
					  		<button class="btn btn-danger btnlogin">Login</button>
					  </div>

					</div>

				</div>
			
		</div>
		
	</div>	 -->

</body>
</html>

<script type="text/javascript">
	
	$(document).ready(function(){


		$(document).off('click','.btnlogin').on('click','.btnlogin',function(e){


			if ($('#username').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Username is Required</div>');
			}else if ($('#password').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Password is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						username:$('#username').val(),
						password:$('#password').val()
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location='dashboard.php';
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

	});

</script>