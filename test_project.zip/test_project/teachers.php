<?php include('header.php'); ?> 
			
			

			<div class="col-md-12" style="margin-top: 50px;">
			
				<div class="panel panel-default">
				  <div class="panel-heading" style="background:#000;color:white;">
				    <h3 class="panel-title" style="font-weight: bold;">Teachers</h3>
				  </div>

				  	<div class="panel-body">
					  <a href="dashboard.php" class="btn btn-danger btnlogin">Back</a>

					  <button class="btn btn-success" data-toggle="modal" data-target="#exampleModal">Add Teachers</button>


					  <div style="margin-top: 50px;">

					  	<?php if (!empty($teachers)) { ?>

					  		<table class="table table-hover">
					  		  <thead>
					  		    <tr style="background: #212529; color: #fff;">
					  		      <th scope="col">#</th>
					  		      <th scope="col">Name</th>
					  		      <th scope="col">Class Name</th>
					  		      <th scope="col">Action</th>
					  		    </tr>
					  		  </thead>
					  		  <tbody>

					  		  	<?php $no = 1; while ($data = $teachers->fetch_array()) { ?>

					  		    <tr>
					  		      <th scope="row"><?=$no?></th>
					  		      <td><?=$data['name']?></td>
					  		      <td>
					  		      	<a href="data.php?edit_teachers=<?=$data['id']?>" class="edit">Edit</a>
					  		      	<a href="data.php?delete_teachers=<?=$data['id']?>" class="delete text-danger" class="text-danger" style="margin-left: 10px;">Delete</a>
					  		      </td>
					  		    </tr>

					  		<?php $no++; } ?>
					  		  </tbody>
					  		</table>
					  	<?php }else{ ?>

					  		<div class="alert alert-danger">No Recourd.</div>
					  	<?php } ?>
					  </div>

					</div>

				</div>
			
		</div>
			
		

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Add Teachers</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="row">

        	<div class="col-md-12">
        		<div class="txtError"></div>
        	</div>

        	<div class="col-md-12">
        		<b>Teacher Name</b>
        		<input type="text" class="form-control" id="name" name="">
        	</div>

        
        	<input type="hidden" name="" id="id">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary  addTeachers">Submit</button>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

<script type="text/javascript">
	
	$(document).ready(function(){


		$(document).off('click','.addTeachers').on('click','.addTeachers',function(e){

			if ($('#name').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Teacher Name is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						teacherame:$('#name').val()
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location="teachers.php";
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

		 $(document).off('click','.edit').on('click','.edit',function(e){
            e.preventDefault();
            var self = $(this);

            $.ajax({

					url:self.attr('href'),
					dataType:'JSON',
					success:function(response){
						if (response.statuscode) 
						{	
							$('#name').val(response.data.name);
							$('#id').val(response.data.id);
							$('#exampleModal').modal('show');
							$('.addTeachers').addClass('updateTeachers');
							$('.updateTeachers').removeClass('addTeachers');

						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});

           });

		 $(document).off('click','.delete').on('click','.delete',function(e){
            e.preventDefault();
            var self = $(this);

            if( confirm('Are you sure, you want to delete this record?') ) {
                $(".loader").removeClass('hidden');
                var url = self.attr('href');
                $.ajax({
                    url: url,
                    dataType: 'JSON',
                    success: function(response) {
                        if( response.statuscode ) {
                            self.closest('tr').remove();
                            alert(response.msg);
                        }
                    }
                });
            }
        });

		 $(document).off('click','.updateTeachers').on('click','.updateTeachers',function(e){

			if ($('#name').val() == '') 
			{
				$('.txtError').html('<div class="alert alert-danger">Teacher Name is Required</div>');
			}else{

				$.ajax({

					url:'data.php',
					type:'POST',
					dataType:'JSON',
					data:{
						updateTeachers_name:$('#name').val(),
						updateTeachers_id:$('#id').val(),
					},
					success:function(response){
						if (response.statuscode) 
						{
							$('.txtError').html('<div class="alert alert-success">'+response.msg+'</div>');
							window.location="teachers.php";
						}else{
							$('.txtError').html('<div class="alert alert-danger">'+response.msg+'</div>');
						}
					},
					error:function(response){
						$('.txtError').html('<div class="alert alert-danger">Something went wrong.</div>');
					}
				});
			}

		});

	});

</script>