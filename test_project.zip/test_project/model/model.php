<?php
include("config.php");
$obj = new connection();
$c = $obj->conn();


class model
{

	public function adminlogin($c,$table,$username,$password)
	{
		
			$select = "select * from $table where username='$username' and password='$password'";
			$result = $c->query($select);

			$fet = $result->fetch_array();
			$no = $result->num_rows;

			if ($no > 0) 
			{
				$_SESSION["aid"]=$fet["id"];
      			$_SESSION["username"]=$fet["username"];

      			return json_encode(['statuscode'=>true,'msg'=>'Login success....!']);
			}else{
				return json_encode(['statuscode'=>false,'msg'=>'Username and Password not match.']);
			}
	}	

	public function check_exist($c,$table,$where)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$select = "select * from $table where $where_con";
		$result = $c->query($select);

		if (!empty($result)) {
			$no = $result->num_rows;
			if ($no > 0) 
			{
				return true;
			}
		}
		return false;
	}

	public function insert($c,$table,$data)
	{
		$k = array_keys($data);
		$kk = implode(",", $k);

		$v = array_values($data);
		$vv = implode("','", $v);

		$ins = "insert into $table ($kk) values ('$vv')";
		$result = $c->query($ins);

		if ($result) 
		{
			return true;
		}else{
			return false;
		}
	}

	public function get_all($c,$table)
	{
		$select = "select * from $table";
		$result = $c->query($select);

		if (!empty($result)) {

			$no = $result->num_rows;

			if ($no > 0) 
			{
				return $result;
			}
		}

		
		return false;
	}

	public function get_with_where($c,$table,$where)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$select = "select * from $table where $where_con";
		$result = $c->query($select);

		if (!empty($result)) {

			$no = $result->num_rows;

			if ($no > 0) 
			{
				return $result;
			}
		}

		return false;
	}

	public function get_with_where_not($c,$table,$where,$classes_id)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$select = "select * from $table where $where_con and id NOT IN ((SELECT student_id FROM attendance WHERE classes_id ='$classes_id'))";
		$result = $c->query($select);

		if (!empty($result)) {

			$no = $result->num_rows;

			if ($no > 0) 
			{
				return $result;
			}
		}

		return false;
	}

	public function get_one_row($c,$table,$where)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$select = "select * from $table where $where_con";
		$result = $c->query($select);
		$no = $result->num_rows;

		if ($no > 0) 
		{
			return $result->fetch_assoc();
		}

		return false;
	}

	public function delete($c,$table,$where)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$select = "DELETE FROM $table where $where_con";
		$result = $c->query($select);

		if ($result) 
		{
			return true;
		}

		return false;
	}

	public function update($c,$table,$data,$where)
	{
		$where_con = '';
		$count = 1;
		foreach ($where as $key => $value) {
			if ($count == 1) 
			{
				$where_con .= $key."='".$value."' ";
			}else{
				$where_con .= "and ".$key."='".$value."' ";
			}
			$count++;
		}

		$update = "UPDATE $table SET $data where $where_con";
		$result = $c->query($update);

		if ($result) 
		{
			return true;
		}

		return false;
	}

	public function get_with_join($c,$table,$select,$join)
	{
		// $where_con = '';
		// echo '<pre>'; print_r($name); die();
		// if (!is_null($where)) 
		// {
		// 	$where_con .= 'where';
		// 	$count = 1;
		// 			foreach ($where as $key => $value) {
		// 				if ($count == 1) 
		// 				{
		// 					$where_con .= $key."='".$value."' ";
		// 				}else{
		// 					$where_con .= "and ".$key."='".$value."' ";
		// 				}
		// 				$count++;
		// 			}
		// }
		
		

	 	$select = "SELECT $select FROM $table $join"; 
		$result = $c->query($select);

		//echo '<pre>'; print_r($result->num_rows); die();

		if (!empty($result)) {

			$no = $result->num_rows;

			if ($no > 0) 
			{
				return $result;
			}
		}else{
			return false;
		}

		//return false;
	}



}		

?>